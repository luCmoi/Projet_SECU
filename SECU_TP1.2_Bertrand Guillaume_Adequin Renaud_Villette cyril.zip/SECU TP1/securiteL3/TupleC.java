package securiteL3;

public class TupleC{
	
	public char lettre1;
	public char lettre2;
	
	public TupleC(char l, char ll){
		this.lettre1 = l;
		this.lettre2 = ll;
	}
}
