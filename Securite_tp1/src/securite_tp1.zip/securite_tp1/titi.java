public String decrypt(String s, int taille) {
        String[] tab = split_text(s, taille);
        this.cle = get_full_key(tab, taille);
        //System.err.println(get_decalage(f));
        System.err.println(this.cle);
        return dechiffreText(s, this.cle);
        //return null;
    }



    String[] split_text(String text, int mod) {
        String[] tab = new String[mod];
        for(int i = 0; i<tab.length; i++)tab[i] = "";
        for (int i = 0; i < text.length(); i++) {
            tab[i%mod] += text.charAt(i);
        }
        return tab;
    }




    int[] get_freq(String s){
        //System.err.println(s);
        int[] freq = new int[TAILLE_ALPHABET];
        for(int i = 0; i<freq.length; i++)freq[i] = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == ' ' || c == '\n') continue;
            freq[c-'a']++;
        }
        return freq;
    }

    int get_decalage(int[] f){
        int max = 0;
        for (int i = 0; i < f.length; i++) {
            //System.err.println(('a' + i) + "   " + f[i]);
            if(f[i]>=f[max]){
                max = i;
            }
        }
        System.err.println((max)+"  "+(char) (max + 97));
        return (max+97) - 'e';

    }

    String get_full_key(String[] tab, int taille){
        String key = "";
        for (int i = 0; i < taille; i++) {
            int [] f = get_freq(tab[i]);
            int a  = get_decalage(f);
            System.err.println(a);
            key += (char) ('a'+a);
            //System.err.println(get_decalage(f)+DEBUT_ALPHABET_ASCII);
        }
        return key;
    }
